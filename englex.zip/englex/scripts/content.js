let intv = setInterval(() => {
    if (document) {
        clearInterval(intv)
        console.log(document.querySelector(".main"))
        console.log(document)
        let mainInterval = setInterval(function () {
            const main = document.querySelector(".main");
            if (main) {
                const container = main.querySelector('.container');
                clearInterval(mainInterval)
                
                const header = document.querySelector(".main-header");
                const heaer_container = header.querySelector('.container');
                container.style.width = '90%';
                heaer_container.style.width = '100%';
            }
        }, 500);
    }
}, 500);

